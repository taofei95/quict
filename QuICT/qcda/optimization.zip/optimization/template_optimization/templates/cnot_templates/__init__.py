#!/usr/bin/env python
# -*- coding:utf8 -*-
# @TIME    : 2020/12/12 6:42 下午
# @Author  : Han Yu
# @File    : __init__.py.py

from .lemma12_2 import lemma12_2
